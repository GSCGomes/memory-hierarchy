# TP3 - OC1
# Guilherme Serra Camargo Gomes
# Felipe Aragão Nogueira de Freitas

# Script para compilação e execução, é necessário ter versão do GCC igual ou superior a gcc 5.0

# para compilar basta utilizar esse comando:
g++ -Wall -std=c++17 main.cpp -o mh.exe

# para executar basta utilizar o executável gerado e o nome do arquivo de entrada
./mh.exe arquivo.txt
